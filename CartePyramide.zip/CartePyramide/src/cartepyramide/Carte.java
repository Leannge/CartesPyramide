/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

public class Carte 
{
    private String couleur;
    private int numero;
    
    public Carte(String couleur, int numero)
    {
      this.couleur=couleur;
      this.numero=numero;
    }
    public String getCouleur()
    {
      return couleur;
    }
    public String getCouleurNR()
    {
        if (couleur == "Trèfle" || couleur == "Pique")
        {
            return "Noire";
        }
        else
            return "Rouge";
            
    }
    public void setCouleur(String c)
    {
      this.couleur=c;
    }
    
    public int getNumero()
    {
        return numero;
    }
    public void setNumero(int n)
    {
        this.numero=n;
    }

    @Override
    public String toString() {
        return numero + " " + couleur; 
    }

}
