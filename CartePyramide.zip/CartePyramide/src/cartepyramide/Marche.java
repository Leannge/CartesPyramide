/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

public class Marche 
{
    int numeroMarche;
    //int numeroJoueur;
    
    public Marche()
    {
        //this.numeroJoueur = numJoueur;
        this.numeroMarche = 1;
    }
    
    public void UpMarche()
    {
        this.numeroMarche++;
    }
    
    public void DownMarche()
    {
        this.numeroMarche--;
    }
    
    public int GetNumMarche()
    {
        return this.numeroMarche;
    }
            
}
