/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Menu extends JFrame
{	
        JPanel       p1, p2, p3, p4, p5;
	JLabel       jLabel1;
	JButton      btnQuit, btNouvellep, btChargerp, btSauvp;
    
    public Menu ()
    {
        //-'Définir la frame avec 5 lignes (pour les 5 pannels) et 1 colonne 
        setLayout(new GridLayout(5,1));
        
        //-'Création des objets
        JLabel       jLabel1 = new JLabel("Choix de la partie :");
        JButton btNouvellep = new JButton("Nouvelle partie");
        JButton btChargerp = new JButton("Charger partie");
        JButton btSauvp = new JButton("Sauvegarder partie");
        JButton      btnQuit       = new JButton("Annuler");
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p5 = new JPanel();
        
        //-'Evenement bouton annuler
        ActionListener actionAnnuler = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                System.exit(1);
            }
	};
        btnQuit.addActionListener(actionAnnuler);

        //-'Evenement bouton Nouvelle Partie
        ActionListener actionNouvellep = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                setVisible(false);
                //new StartGame();
                new StartGame();
                PlusieursJoueurs tache2 = new PlusieursJoueurs();
            }
	};
        btNouvellep.addActionListener(actionNouvellep);
        
        //-'Ajout des boutons dans le panel
	p1.add(jLabel1);
        p2.add(btNouvellep);
        p3.add(btChargerp);
        p4.add(btSauvp);
        p5.add(btnQuit);
                
	//-'Ajout pannel à la frame
        add(p1);
        add(p2);
        add(p3);
        add(p4);
        add(p5);
        
        //-'Design du menu
        setTitle("Menu Jeu de carte Pyramide : ");
        setLocation(50, 50);
        setSize(400,200);
        setVisible(true);
        setLocationRelativeTo(null);
        btnQuit.setBackground(Color.decode("#FF866A"));
        //pack();
        
    }
    
}