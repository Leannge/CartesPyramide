/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class PaquetCartes 
{
    private int taille_jeu;
    private ArrayList<Carte> listeCartes = new ArrayList<Carte>();
    private int NumeroCartePioche;
    private ArrayList<Carte> listeCartesTire = new ArrayList<Carte>();


    public PaquetCartes(int tailledujeu)
    {
        this.taille_jeu = tailledujeu;       
    }
    
    public void CreerJeu()
    {
        for (int i = 0; i < taille_jeu/4; i++) 
        {
            listeCartes.add(new Carte("Trefle", i+1));
            listeCartes.add(new Carte("Coeur", i+1));
            listeCartes.add(new Carte("Carreau", i+1));
            listeCartes.add(new Carte("Pique", i+1));
        }
    }
    
    public void CreerJeu(int tailledujeu)
    {
        this.taille_jeu = tailledujeu;
        for (int i = 0; i < taille_jeu/4; i++) 
        {
            listeCartes.add(new Carte("Trefle", i+1));
            listeCartes.add(new Carte("Coeur", i+1));
            listeCartes.add(new Carte("Carreau", i+1));
            listeCartes.add(new Carte("Pique", i+1));
        }
    }
    
    public Carte Piocher()
    {   
        if(taille_jeu > 0)
        {
        //-'Prend une carte au hasard dans le paquet
        NumeroCartePioche = (int) (Math.random() * (taille_jeu - 1));
        //-'Ajoute dans liste des cartes tirées
        listeCartesTire.add(listeCartes.get(NumeroCartePioche));
        //-'Retourne la carte tirée
        return listeCartes.get(NumeroCartePioche);
        }
        else
        {
            CreerJeu(52);
            //-'Prend une carte au hasard dans le paquet
            NumeroCartePioche = (int) (Math.random() * (taille_jeu - 1));
            //-'Ajoute dans liste des cartes tirées
            listeCartesTire.add(listeCartes.get(NumeroCartePioche));
            //-'Retourne la carte tirée
            return listeCartes.get(NumeroCartePioche);
        }
        
    }
    
    public void EnleverPioche()
    {
        listeCartes.remove(NumeroCartePioche);
        taille_jeu = taille_jeu -1;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
    }
    
    public int GetnbCartesPaquet()
    {
        return taille_jeu;
    }
}
