/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PlateauJoueurs extends JFrame
{
        JPanel       p1, p2, p3, p4;
	JLabel       labCarteTire, labnbCartesPaquet, labChoixCouleur, labNbMarche;
	JButton      btPioche, btRouge, btNoir, btStart;
        private String       coNRChoisie;

    public PlateauJoueurs(){        
        
        //-'Définir la frame avec 4 lignes (pour les 2 pannels) et 3 colonnes 
        setLayout(new GridLayout(4,3));
        
        //-'Création des boutons
        JButton btPioche = new JButton("Pioche");
        JButton btRouge = new JButton("Rouge");
        JButton btNoir = new JButton("Noire");
        JButton btStart = new JButton("Play");
        
        //-'Création des labels
        labCarteTire = new JLabel("");
        labnbCartesPaquet = new JLabel("");
        labChoixCouleur = new JLabel("");
        labNbMarche = new JLabel("");
                
        //-'Création des panels
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        
        //-'Création autres objets
        coNRChoisie = new String("");
        
        //-'Mettre invisible les boutons
        btPioche.setVisible(false);
        btNoir.setVisible(false);
        btRouge.setVisible(false); 
        
        //-'Création du paquet de carte
        PaquetCartes paquet = new PaquetCartes(52);
        paquet.CreerJeu();
        
        //-'Mettre le joueur à la marche 1 par défaut et l'afficher
        Marche marcheJoueur = new Marche();
        
        //-'Evenement du bouton Start
        ActionListener actionStart = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {  
                labChoixCouleur.setText("Choisissez une couleur");
                btNoir.setVisible(true);
                btRouge.setVisible(true); 
                btStart.setVisible(false);
                labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
            }
	};
        btStart.addActionListener(actionStart);
        
        //-'Evenement du bouton Rouge
        ActionListener actionCoCarteR = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                coNRChoisie = "Rouge";
                btPioche.setVisible(true);
                btNoir.setVisible(false);
                btRouge.setVisible(false);
                labChoixCouleur.setVisible(false);
            }
	};
        btRouge.addActionListener(actionCoCarteR);

        //-'Evenement du bouton Noir
        ActionListener actionCoCarteN = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                coNRChoisie = "Noire";
                btPioche.setVisible(true);
                btRouge.setVisible(false);
                btNoir.setVisible(false);
                labChoixCouleur.setVisible(false);
            }
	};
        btNoir.addActionListener(actionCoCarteN);

        //-'Evenement du bouton "Pioche"
        ActionListener actionPioche = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                    //Piocher une carte dans le paquet et l'afficher
                    Carte cartepiocher = paquet.Piocher();
                    labCarteTire.setText(cartepiocher.toString());
                    paquet.EnleverPioche();
                    p3.add(labCarteTire);
                    add(p3);
                    System.out.print("co choisie : " + coNRChoisie + " ");
                    System.out.print("co piocher : " + cartepiocher.getCouleurNR());
                    
                    //Si on est a la marche 1
                    if(marcheJoueur.GetNumMarche() == 1)
                    {
                        
                        btRouge.setVisible(true);
                        btNoir.setVisible(true);
                        btPioche.setVisible(false);
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleurNR() == coNRChoisie)
                        {
                            marcheJoueur.UpMarche();
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche() + "/");
                            
                        }
                    }
                    
                    //Si on est à la marche 2
                    if(marcheJoueur.GetNumMarche() == 2)
                    {
                        btRouge.setVisible(true);
                        btNoir.setVisible(true);
                        btPioche.setVisible(false);
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleurNR() == coNRChoisie)
                        {
                            marcheJoueur.UpMarche();
                            btRouge.setVisible(false);
                            btNoir.setVisible(false);
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche() + "/");
                        }
                    }
                    
                    //Afficher le nombre de cartes restantes dans le paquet
                    labnbCartesPaquet.setText("Cartes restantes : " + paquet.GetnbCartesPaquet());
                    p4.add(labnbCartesPaquet);
                    add(p4);
            }
	};
        btPioche.addActionListener(actionPioche);
        
        //-'Ajout des boutons dans le panel
	p1.add(btPioche);
        p1.add(labChoixCouleur);
        p1.add(btStart);
        p2.add(btRouge);
        p2.add(btNoir);
        p3.add(labCarteTire);
        p3.add(labNbMarche);
        p4.add(labnbCartesPaquet);
        
	//-'Ajout pannel à la frame
        add(p1);
        add(p2);
        add(p3);
        add(p4);
        
        //-'Design du menu
        setTitle("Plateau jeu Pyramide : ");
        setLocation(50, 50);
        setSize(400,200);
        setVisible(true);
        setLocationRelativeTo(null);
        labNbMarche.setForeground(Color.decode("#FF866A"));

    }
    
    
}


