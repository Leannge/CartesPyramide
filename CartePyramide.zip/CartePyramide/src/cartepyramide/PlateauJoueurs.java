/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PlateauJoueurs extends JFrame
{
        JPanel       p1, p2, p3, p4;
	JLabel       labCarteTire, labnbCartesPaquet;
	JButton      btPioche, btRouge, btNoir;
        private String       coNRChoisie;
    
    public PlateauJoueurs(){        
        
        //-'//-'Définir la frame avec 2 lignes (pour les 2 pannels) et 1 colonne 
        setLayout(new GridLayout(4,2));
        
        //-'Création des boutons
        JButton btPioche = new JButton("Pioche");
        JButton btRouge = new JButton("Rouge");
        JButton btNoir = new JButton("Noire");
        
        //-'Création des labels
        labCarteTire = new JLabel("");
        labnbCartesPaquet = new JLabel("");
        
        //-'Création des panels
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        
        //-'Création autres objets
//        String coNRChoisie = new String("");
        
        //Mettre invisible bouton pioche
        btPioche.setVisible(false);
        
        //Création du paquet de carte
        PaquetCartes paquet = new PaquetCartes(52);
        paquet.CreerJeu();
        
        //-'Evenement du bouton Rouge
//        ActionListener actionCoCarteNR = new ActionListener() 
//        {
//            public void actionPerformed(ActionEvent e) 
//            {
//                coNRChoisie = "Rouge";
//                
//            }
//	};
//        btRouge.addActionListener(actionCoCarteNR);

        //-'Evenement du bouton Noir
   
        //-'Evenement du bouton "Pioche"
        ActionListener actionPioche = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                    //Piocher une carte dans le paquet et l'afficher
                    Carte cartepiocher = paquet.Piocher();
                    //System.out.print(cartepiocher.getCouleur());
                    labCarteTire.setText(cartepiocher.toString());
                    paquet.EnleverPioche();
                    p3.add(labCarteTire);
                    add(p3);
                    
                    //Afficher le nombre de cartes restantes dans le paquet
                    labnbCartesPaquet.setText("Cartes restantes : " + paquet.GetnbCartesPaquet());
                    p4.add(labnbCartesPaquet);
                    add(p4);
            }
	};
        btPioche.addActionListener(actionPioche);
        
        //-'Ajout des boutons dans le panel
	p1.add(btPioche);
        p2.add(btRouge);
        p2.add(btNoir);
        p3.add(labCarteTire);
        p4.add(labnbCartesPaquet);
        
	//-'Ajout pannel à la frame
        add(p1);
        add(p2);
        add(p3);
        add(p4);
        
        //-'Design du menu
        setTitle("Plateau jeu Pyramide : ");
        setLocation(50, 50);
        setSize(400,200);
        setVisible(true);
        setLocationRelativeTo(null);

    }
    
    
}


