/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

public class PlusieursJoueurs implements Runnable 
{
  Thread  UnThread ;
   PlusieursJoueurs ( ) 
   {
   //initialisations du constructeur 
   UnThread = new Thread ( this , "thread secondaire");
   UnThread.start( ) ; 
   }
   public void run ( ) 
   {
       //actions du thread secondaire
       new StartGame().setVisible(true);
       System.out.println("Thread lancé");
   }
}
