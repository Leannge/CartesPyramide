/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author lea.fraioli
 */
public class Règles extends JFrame
{
    JPanel p1, p2;
    JTextArea tf1;
    JButton b1;
    
    public Règles()
    {
        this.setLayout(new GridLayout(2,1));
        p1 = new JPanel();
        p2 = new JPanel();
        tf1 = new JTextArea("Les 2 joueurs jouent chacun leur tour l’un après l’autre. Ils sont tout d’abord placés devant une pyramide ayant 5 marches pour atteindre le sommet.\n"
                + " Le but du jeu est d’atteindre le sommet de la pyramide en premier.\n" +
"On procède à un tirage au sort pour savoir si joueur 1 ou joueur 2 commence à jouer. " +
"Chaque joueur débute la partie devant les marches.\n" +
"•Marche zéro : Le joueur choisit une couleur rouge ou noire puis tire une carte. Si la carte est de la même couleur que celle choisie le joueur monte à la première marche sinon\n"
                + " il reste sur la marche zéro.\n" +
"•Première marche : Idem, le joueur choisit une couleur rouge ou noire puis tire une carte. Si la carte est de la même couleur que celle choisie le joueur monte à la deuxième\n "
                + "marche sinon il reste sur la première marche.\n" +
"•Deuxième marche : Le joueur choisit la couleur (Pique, trèfle, cœur, carreau) puis tire la carte. Si la carte est de la même couleur le joueur monte à la troisième marche sinon\n"
                + " il reste à la deuxième marche.\n" +
"•Troisième marche : Idem, le joueur choisit la couleur (Pique, trèfle, cœur, carreau) puis tire la carte. Si la carte est de la même couleur le joueur monte à la quatrième\n "
                + "marche sinon il reste à la troisième marche.\n" +
"•Quatrième marche : Le joueur choisit si la carte qu’il va tirer va être plus ou moins forte que celle tirée précédemment puis tire la carte. S’il a faux alors le joueur descend\n"
                + " à la troisième marche, si la carte est égale il reste sur la quatrième marche, s’il a juste alors il arrive au sommet de la pyramide.");

        tf1.setEditable(false);
        b1=new JButton("Ok");
        
        // définition d'une action boutton "ok"
		ActionListener l1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) 
                        {
                            setVisible(false);
			}
		};
                
                b1.addActionListener(l1);
        p1.add(tf1);
        p2.add(b1);

        add(p1);
        add(p2);
    }
}
