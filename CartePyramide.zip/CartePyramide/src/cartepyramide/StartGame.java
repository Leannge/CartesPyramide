/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StartGame extends JFrame
{
        JPanel           p1, p2, p3, p4, p5;
	JLabel           labCarteTire, labnbCartesPaquet, labQueFaire, labNbMarche;
	JButton          btPioche, btRouge, btNoir, btStart, btPlus, btMoins;
        JComboBox        comboChoixCo;
        private String   coNRChoisie;
        private String[] coChoisie;
        private boolean  plusOuMoins;
        private int      numCartePrec;
//Joueur nameJoueur à mettre
    public StartGame(){        
        
        //-'Définir la frame avec 5 lignes (pour les 5 pannels) et 3 colonnes 
        setLayout(new GridLayout(5,3));
        
        //-'Création des boutons
        JButton btPioche = new JButton("Pioche");
        JButton btRouge = new JButton("Rouge");
        JButton btNoir = new JButton("Noire");
        JButton btStart = new JButton("Play");
        JButton btPlus = new JButton("Plus");
        JButton btMoins = new JButton("Moins");
        
        //-'Création des labels
        labCarteTire = new JLabel("");
        labnbCartesPaquet = new JLabel("");
        labQueFaire = new JLabel("");
        labNbMarche = new JLabel("");
                
        //-'Création des panels
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p5 = new JPanel();
        
        //-'Création autres objets
        coNRChoisie = new String("");
        coChoisie = new String[]{"Trefle", "Coeur", "Carreau", "Pique"};
        comboChoixCo = new JComboBox(coChoisie);
        
        //-'Mettre invisible les éléments suivants
        btPioche.setVisible(false);
        btNoir.setVisible(false);
        btRouge.setVisible(false); 
        comboChoixCo.setVisible(false);
        btPlus.setVisible(false);
        btMoins.setVisible(false);
        
        //-'Création du paquet de carte
        PaquetCartes paquet = new PaquetCartes(52);
        paquet.CreerJeu();
        
        //-'Mettre le joueur à la marche 1 par défaut et l'afficher
        Marche marcheJoueur = new Marche();
        
        //-'Evenement du bouton Start
        ActionListener actionStart = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {  
                labQueFaire.setText("Choisissez une couleur (N/R): ");
                btNoir.setVisible(true);
                btRouge.setVisible(true); 
                btStart.setVisible(false);
                labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
            }
	};
        btStart.addActionListener(actionStart);
        
        //-'Evenement du bouton Rouge
        ActionListener actionCoCarteR = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                coNRChoisie = "Rouge";
                btPioche.setVisible(true);
                btNoir.setVisible(false);
                btRouge.setVisible(false);
                labQueFaire.setText("");
            }
	};
        btRouge.addActionListener(actionCoCarteR);

        //-'Evenement du bouton Noir
        ActionListener actionCoCarteN = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                coNRChoisie = "Noire";
                btPioche.setVisible(true);
                btRouge.setVisible(false);
                btNoir.setVisible(false);
                labQueFaire.setText("");
            }
	};
        btNoir.addActionListener(actionCoCarteN);
        
        //-'Evenement de la combobox Choix couleur
        ActionListener actionCoCarte = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btPioche.setVisible(true);
                comboChoixCo.setVisible(false);
            }
	};
        comboChoixCo.addActionListener(actionCoCarte);

        
        //-'Evenement du bouton Plus
        ActionListener actionPlus = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {  
                plusOuMoins = true;
                btPioche.setVisible(true);
                btPlus.setVisible(false);
                btMoins.setVisible(false);
            }
	};
        btPlus.addActionListener(actionPlus);
        
        //-'Evenement du bouton Moins
        ActionListener actionMoins = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {  
                plusOuMoins = false;
                btPioche.setVisible(true);
                btPlus.setVisible(false);
                btMoins.setVisible(false);
            }
	};
        btMoins.addActionListener(actionMoins);
        
        //-'Evenement du bouton "Pioche"
        ActionListener actionPioche = new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                    //Piocher une carte dans le paquet et l'afficher
                    Carte cartepiocher = paquet.Piocher();
                    labCarteTire.setText(cartepiocher.toString());
                    paquet.EnleverPioche();
                    p3.add(labCarteTire);
                    add(p3);
                    
                    //Si le joueur est sur la marche 1
                    if(marcheJoueur.GetNumMarche() == 1)
                    {
                        labQueFaire.setText("Choisissez une couleur(N/R) : ");
                        btRouge.setVisible(true);
                        btNoir.setVisible(true);
                        btPioche.setVisible(false);
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleurNR() == coNRChoisie)
                        {
                            marcheJoueur.UpMarche();
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
                        }
                    }
                    
                    //Si le joueur est sur la marche 2
                    else if(marcheJoueur.GetNumMarche() == 2)
                    {
                        btRouge.setVisible(true);
                        btNoir.setVisible(true);
                        btPioche.setVisible(false);
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleurNR() == coNRChoisie)
                        {
                            marcheJoueur.UpMarche();
                            btRouge.setVisible(false);
                            btNoir.setVisible(false);
                            comboChoixCo.setVisible(true);
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
                            labQueFaire.setText("Choisissez une couleur : ");
                        }
                    }
                    
                    //Si le joueur est sur la marche 3
                    else if(marcheJoueur.GetNumMarche() == 3)
                    {
                        comboChoixCo.setVisible(true);
                        btPioche.setVisible(false);
                        comboChoixCo.setVisible(true);
                        
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleur() == comboChoixCo.getSelectedItem())
                        {
                            marcheJoueur.UpMarche();
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche()); 
                        }
                    }
                    
                    //Si le joueur est sur la marche 4
                    else if(marcheJoueur.GetNumMarche() == 4)
                    {
                        comboChoixCo.setVisible(true);
                        btPioche.setVisible(false);
                        comboChoixCo.setVisible(true);
                        
                        //Si la carte est de la bonne couleur monter d'une marche
                        if(cartepiocher.getCouleur() == comboChoixCo.getSelectedItem())
                        {
                            marcheJoueur.UpMarche();
                            comboChoixCo.setVisible(false);
                            btPlus.setVisible(true);
                            btMoins.setVisible(true);
                            labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
                            labQueFaire.setText("Plus ou moins que la carte précédente : ");
                        }
                        numCartePrec = cartepiocher.getNumero();
                    }
                    
                    //Si le joueur est sur la marche 5
                    else if(marcheJoueur.GetNumMarche() == 5)
                    {
                        btPioche.setVisible(false);
                        btPlus.setVisible(true);
                        btMoins.setVisible(true);
                        
                        //Si le joueur a choisi plus
                        if(plusOuMoins == true)
                            {
                                if(cartepiocher.getNumero() > numCartePrec)
                                    {
                                        marcheJoueur.UpMarche();
                                        btPlus.setVisible(false);
                                        btMoins.setVisible(false);
                                        labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
                                        labQueFaire.setText("Tu as gagné la partie");
                                    }
                                
                            }
                        
                        //Si le joueur a choisi moins
                        else if(plusOuMoins == false)
                            {
                                if(cartepiocher.getNumero() < numCartePrec)
                                {
                                    marcheJoueur.UpMarche();
                                    btPlus.setVisible(false);
                                    btMoins.setVisible(false);
                                    labNbMarche.setText("Marche numéro : " + marcheJoueur.GetNumMarche());
                                    labQueFaire.setText("Tu as gagner la partie");
                                }
                            }
                        
                        numCartePrec = cartepiocher.getNumero();
                    }
                    
                    //Afficher le nombre de cartes restantes dans le paquet
                    labnbCartesPaquet.setText("Cartes restantes : " + paquet.GetnbCartesPaquet());
                    p4.add(labnbCartesPaquet);
                    add(p4);
            }
	};
        btPioche.addActionListener(actionPioche);
        
        //-'Ajout des boutons dans le panel
        p1.add(labQueFaire);
        p1.add(labNbMarche);
        p2.add(btStart);
        p2.add(btPioche);
        p3.add(btRouge);
        p3.add(btNoir);
        p4.add(labCarteTire);
        p4.add(labnbCartesPaquet);
        p5.add(btPlus);
        p5.add(btMoins);
        p5.add(comboChoixCo);
        
        
	//-'Ajout pannel à la frame
        add(p1);
        add(p2);
        add(p3);
        add(p4);
        add(p5);
        
        //-'Design du menu
        setTitle("Plateau jeu Pyramide : ");
        setLocation(50, 50);
        setSize(500,200);
        setVisible(true);
        setLocationRelativeTo(null);
        labNbMarche.setForeground(Color.decode("#FF866A"));
        btPioche.setBackground(Color.decode("#87CEEB"));

    }
    
    
}


