/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */

public class Joueur 
{
    private int numeroJoueur=0;
    
    public Joueur()
    {
        this.numeroJoueur ++;
    }
    
    public int GetNumJoueur()
    {
        return numeroJoueur;
    }
    
    public void SetNumJoueur(int numJoueur)
    {
        this.numeroJoueur = numJoueur;
    }
}
