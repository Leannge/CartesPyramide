/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;


/**
 *
 * @author lea.fraioli
 */

public class Cartes 
{
    private String couleur;
    private int numero;
    
    public Cartes(String couleur, int numero)
    {
      this.couleur=couleur;
      this.numero=numero;
    }
    public String getCouleur()
    {
      return couleur;
    }
    public void setCouleur(String c)
    {
      this.couleur=c;
    }
    
    public int getNumero()
    {
        return numero;
    }
    public void setNumero(int n)
    {
        this.numero=n;
    }
    
    public String ToString()
    {
        return numero + " " + couleur; 
    }

}
