/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;


/**
 *
 * @author lea.fraioli
 */

public class Cartes 
{
    private enum couleur{trefle, carreau, coeur, pique};
    int numero;
    
    public Carte(enum couleur, int numero)
    {
      this.couleur()=couleur;
      
    }
    public Couleur getCouleur()
    {
      return couleur;
    }
    public void setCouleur(Couleur c)
    {
      this.couleur=c;
    }
    
    public int getNumero()
    {
        return numero;
    }
    public void setNumero(int n)
    {
        this.numero=n;
    }
    
    public String ToString()
    {
        return "la carte est : " numero + " " + couleur; 
    }

}
