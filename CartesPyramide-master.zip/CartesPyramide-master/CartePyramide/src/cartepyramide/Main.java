/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

/**
 *
 * @author lea.fraioli
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            //Reglage de la fenêtre du menu
            Menu compo = new Menu();
            compo.setTitle("Menu Jeu de carte Pyramide : ");
            compo.setLocation(50, 50);
            compo.setSize(400,200);
            compo.setVisible(true);
            compo.setLocationRelativeTo(null);
            //compo.pack();

//            PlateauJoueurs compo2 = new PlateauJoueurs();
//            compo2.setTitle("Jeu de carte Pyramide : ");
//            compo2.setLocation(50, 50);
//            compo2.setSize(400,200);
//            compo2.setVisible(true);
//            compo2.setLocationRelativeTo(null);

            //Création du paquet de carte
            PaquetCartes paquet = new PaquetCartes(32);
            paquet.CreerJeu();
            
            //Piocher une carte dans le paquet et l'afficher
            Cartes cartepiocher = paquet.Piocher();
            System.out.print(cartepiocher.toString());
	}
    
}
