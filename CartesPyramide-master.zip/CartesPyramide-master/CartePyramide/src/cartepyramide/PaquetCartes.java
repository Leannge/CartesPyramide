/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 *
 * @author DEV_SNEF5
 */
public class PaquetCartes 
{
    private int taille_jeu;
    private ArrayList<Cartes> listeCartes = new ArrayList<Cartes>();


    public PaquetCartes(int tailledujeu)
    {
        this.taille_jeu = tailledujeu;       
    }
    
    public void CreerJeu()
    {
        for (int i = 0; i < taille_jeu; i++) {
            listeCartes.add(new Cartes("Trefle", i+1));
        }
        
        //this.listeCartes = new ArrayList(Arrays.asList(tabCartes));
    }
    public Cartes Piocher()
    {
        int indiceAuHasard = (int) (Math.random() * (listeCartes.size() - 1));
        return listeCartes.get(indiceAuHasard);
    }
}
