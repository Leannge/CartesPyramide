/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author DEV_SNEF5
 */
public class PaquetCartes 
{
    public final int TAILLE_JEU=32;
    private ArrayList<String> listeCartes = new ArrayList<String>();
    //private Cartes[] = new Cartes[];


    public PaquetCartes()
    {
        int j;
        for(int i=0; i<TAILLE_JEU; i++)
        {
            j=i+1;
            Integer.toString(j);
            listeCartes.add(j + "");
            //Cartes[i] = new Cartes("Trefle", i);
            //listeCartes.add(Cartes[i].ToString());
        }
    }
    public String Piocher()
    {
        int indiceAuHasard = (int) (Math.random() * (listeCartes.size() - 1));
        return listeCartes.get(indiceAuHasard);
    }
}
