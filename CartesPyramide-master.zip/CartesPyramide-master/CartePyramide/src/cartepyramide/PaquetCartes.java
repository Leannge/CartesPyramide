/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author DEV_SNEF5
 */
public class PaquetCartes 
{
    public final int TAILLE_JEU=32;
    public Random generateur= new Random();
    private ArrayList<String> listeCartes = new ArrayList<String>();

    public PaquetCartes()
    {
        int j;
        for(int i=0; i<TAILLE_JEU; i++)
        {
            j=i+1;
            Integer.toString(j);
            listeCartes.add(j + "");
        }
    }
}
