/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 *
 * @author DEV_SNEF5
 */
public class PaquetCartes 
{
    private int taille_jeu;
    private ArrayList<String> listeCartes = new ArrayList<String>();
    private Cartes[] tabCartes = new Cartes[taille_jeu];


    public PaquetCartes(int tailledujeu)
    {
        this.taille_jeu = tailledujeu;       
    }
    
    public void CreerJeu()
    {
        for(int i=0; i<tabCartes.length; i++)
        {
            this.tabCartes[i] = new Cartes("Trefle", i+1);
            this.listeCartes.add(tabCartes[i].ToString());
        }
        //this.listeCartes = new ArrayList(Arrays.asList(tabCartes));
    }
    public String Piocher()
    {
        int indiceAuHasard = (int) (Math.random() * (listeCartes.size() - 1));
        return listeCartes.get(indiceAuHasard);

    }
}
