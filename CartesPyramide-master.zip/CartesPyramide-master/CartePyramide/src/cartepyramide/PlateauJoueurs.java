/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author DEV_SNEF5
 */
public class PlateauJoueurs extends JFrame
{
    JPanel p1;
    JLabel image;
    ImageIcon icon;
    
    public PlateauJoueurs()
    {
        //setLayout(new GridLayout(1,1));
        p1 = new JPanel(); 
        icon = new ImageIcon("pyramide.JPG");
        image = new JLabel(icon);
        //p1.setLayout(new BorderLayout, CENTER); 
        p1.add(image);
    }

}
