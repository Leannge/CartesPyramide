/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartepyramide;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author DEV_SNEF5
 */
public class PlateauJoueurs extends JFrame
{
//    JPanel p1;
//    JLabel image;
//    ImageIcon icon;
//    
//    public PlateauJoueurs()
//    {
//        //setLayout(new GridLayout(1,1));
//        p1 = new JPanel(); 
//        icon = new ImageIcon("pyramide.JPG");
//        image = new JLabel(icon);
//        //p1.setLayout(new BorderLayout, CENTER); 
//        p1.add(image);
//    }
    JPanel jPanel1 = new JPanel();
    ImageIcon icone;
    JLabel image = new JLabel(icone);
    public PlateauJoueurs(){
        /**
         * On récupére l'image
         */
         icone = new ImageIcon("pyramide.JPG");
        /**
         * On dimenssionne le JLabel au dimension de la baniere
         */   
        image.setSize(jPanel1.getWidth(),jPanel1.getHeight());
        /**
         * On ajoute le JLabel dans le JPanel
         */
        jPanel1.add(image);
        /**
         * On appel la Méthode PaintComponent du JPanel pour qu'il affiche la baniere
         */
        jPanel1.repaint();
        /**
         * On ajoute le JPanel dans la fenetre principale
         */
        add(jPanel1);
        /**
         * La fenetre principale se dimenssionne automatiquement
         */
        pack();
        /**
         * Quand on appui sur le bouton pour fermer la fenêtre l'application s'arrete
         */
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        /**
         * On rend la fenêtre principale visible.
         */
        setVisible(true);
    }
    public static void main(String[] args) {
        /**
         * Appel du constructeur de la class PlateauJoueur
         */
        new PlateauJoueurs();
    }
}


