/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pyramide.movement;

/**
 * Cette interface permet de donner les états de déplacement d'un objet
 * @author Léa
 */
public interface EvtMove {
    
    /**
     * Lorsque le mouvement commence
     * @param m Correspond au Movement
     */
    public void evtStartMove(Movement m);
    
    /**
     * Lorsque le mouvement est en pause
     * @param m Correspond au Movement
     */
    public void evtPauseMove(Movement m);
    
    /**
     * Lorsque le mouvement est terminé
     * @param m Correspond au Movement
     */
    public void evtFinishMove(Movement m);
    
    /**
     * Lorsque le composant qui se déplace a une nouvelle position
     * @param m Correspond au Movement
     * @param x Correspond à la nouvelle coordonnée x
     * @param y Correspond à la nouvelle coordonnée y
     */
    public void evtPositionMove(Movement m, int x, int y);
    
}
