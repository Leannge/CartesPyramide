/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pyramide.movement;



import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;



/**
 * Cette classe permet de créer des objets Movement qui serviront à déplacer un composant dans un container dont le layout est null
 * @author Léa
 */
public class Movement {
    
    
    
    private static int cptID = 0;
    
    private final int id;
    private final Component component;
    private final Container componentParent;
    private final Vector vector;
    private int speed;
    private Point start = new Point(0, 0);
    private Point end = new Point(0, 0);
    private final List<EvtMove> listEvt;
    private ThreadMove tm;
    private boolean move;
    private boolean started;
    private boolean paused;

    
    
//CONSTRUCTOR
    /**
     * Crée un objet Mouvement
     * @param container Correspond au container qui contient l'objet à bouger (attention le layout doit être null)
     * @param toMove Correpsond à l'objet qui va bouger
     * @param vector Correspond au vecteur de déplacement
     * @param speedLatence Correspond au temps de latence entre chaque déplacement pixelisé
     */
    public Movement(Container container, Component toMove, Vector vector, int speedLatence) {
        this.id = cptID++;
        this.componentParent = new JPanel();
        this.componentParent.setSize(container.getSize());
        this.componentParent.setPreferredSize(container.getPreferredSize());
        this.componentParent.setMinimumSize(container.getMinimumSize());
        this.componentParent.setMinimumSize(container.getMaximumSize());
        this.component = toMove;
        this.vector = vector;
        this.speed  = speedLatence;
        this.start  = new Point(vector.getStart().x, vector.getStart().y);
        this.end    = new Point(vector.getEnd().x,   vector.getEnd().y);
        this.listEvt = new ArrayList<>();
    }
    
    
    
//METHODES PUBLICS
    /**
     * Ajoute un évènement EvtMove sur cet objet
     * @param em Correspond à la classe qui implémente EvtMove
     */
    public void addListener(EvtMove em){
        this.listEvt.add(em);
    }
    
    /**
     * Enlève un évènement EvtMove sur cet objet
     * @param em Correspond à la classe qui implémente EvtMove
     */
    public void removeListener(EvtMove em){
        if(em != null && this.listEvt.contains(em)) this.removeListener(em);
    }

    /**
     * Renvoie le résultat de la méthode hashCode()
     * @return Retourne le résultat de la méthode hashCode()
     */
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + this.id;
        return hash;
    }

    /**
     * Renvoie le résultat de la méthode equals()
     * @param obj Correspond à l'objet à comparer
     * @return Retourne le résultat de la méthode equals()
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Movement other = (Movement) obj;
        return this.id == other.id;
    }

    /**
     * Renvoie l'ID de l'objet
     * @return Retourne l'ID de l'objet
     */
    public int getId() {
        return id;
    }

    /**
     * Renvoie le temps de latence entre chaque déplacement pixelisé
     * @return Retourne le temps de latence entre chaque déplacement pixelisé
     */
    public int getSpeedLatence() {
        return speed;
    }

    /**
     * Modifie le temps de latence entre chaque déplacement pixelisé
     * @param speedLatence Correspond au nouveau temps de latence
     */
    public void setSpeedLatence(int speedLatence) {
        this.speed = speedLatence;
    }

    /**
     * Renvoie le composant qui bouge
     * @return Retourne le composant qui bouge
     */
    public Component getComponent() {
        return component;
    }

    /**
     * Renvoie le vecteur de déplacement
     * @return Retourne le vecteur de déplacement
     */
    public Vector getVector() {
        return vector;
    }
    
    /**
     * Renvoie si le composant bouge
     * @return Retourne true, si c'est le cas, false sinon
     */
    public boolean isMove(){
        return move;
    }
    
    /**
     * Lance le déplacement
     */
    public void startMovement(){
        if(!started){
            this.tm = new ThreadMove();
            this.tm.start();
        }else if(paused){
            if(tm!=null) this.tm.resumeT();
        }
    }
    
    /**
     * Met en pause le déplacement
     */
    public void pauseMovement(){
        if(started){
            if(tm!=null) this.tm.pause();
        }
    }
    
    /**
     * Stoppe le déplacement
     */
    public void stopMovement(){
        if(started){
            if(tm!=null) this.tm.finish();
        }
    }
    
    /**
     * Déplace le composant toMove à partir d'un vecteur de déplacement
     * @param container Correspond au container qui contient l'objet à bouger (attention le layout doit être null)
     * @param toMove Correpsond à l'objet qui va bouger
     * @param vector Correspond au vecteur de déplacement
     * @param speedLatence Correspond au temps de latence entre chaque déplacement pixelisé
     */
    public static void move(Container container, Component toMove, Vector vector, int speedLatence){
        new Movement(container, toMove, vector, speedLatence).startMovement();
    }
    
    /**
     * Déplace le composant toMove à partir d'un vecteur de déplacement
     * @param container Correspond au container qui contient l'objet à bouger (attention le layout doit être null)
     * @param toMove Correpsond à l'objet qui va bouger
     * @param vector Correspond au vecteur de déplacement
     * @param speedLatence Correspond au temps de latence entre chaque déplacement pixelisé
     * @param em Correspond à la classe qui implémente EvtMove
     */
    public static void move(Container container, Component toMove, Vector vector, int speedLatence, EvtMove em){
        Movement m = new Movement(container, toMove, vector, speedLatence);
        if(em!=null) m.addListener(em);
        m.startMovement();
    }
    
    
    
//CLASS
    /**
     * Correspond à la classe qui va se charger du déplacement
     */
    private class ThreadMove extends Thread implements EvtMove{
        private boolean run;
        private boolean pause;
        private final int id;

        @SuppressWarnings("LeakingThisInConstructor")
        public ThreadMove() {
            this.run = true;
            this.pause = false;
            this.id = cptID-1;
            addListener(this);
        }

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 59 * hash + this.id;
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final ThreadMove other = (ThreadMove) obj;
            return this.id == other.id;
        }
        
        public void pause(){
            this.pause = true;
        }
        
        public void resumeT(){
            this.pause = false;
        }
        
        public void finish(){
            resumeT();
            this.run = false;
        }
        
        @Override
        public void run() {
            Point startPG   = start.translatePointToPointGraph(componentParent);
            Point endPG     = end.translatePointToPointGraph(componentParent);
            
            if(!listEvt.isEmpty()){
                for(int i=0;i<listEvt.size();i++){
                    listEvt.get(i).evtStartMove(Movement.this);
                }
            }
            
            if(startPG.getX() == endPG.getX() && startPG.getY() == endPG.getY()){
                moveToCenter(startPG, endPG);
            }else{
                if((startPG.getX() == endPG.getX()) && (startPG.getY() != endPG.getY()) && (startPG.getY() < endPG.getY())){
                    moveToNorth(startPG, endPG);
                }else{
                    if((startPG.getX() == endPG.getX()) && (startPG.getY() != endPG.getY()) && (startPG.getY() > endPG.getY())){
                        moveToSouth(startPG, endPG);
                    }else{
                        if((startPG.getY() == endPG.getY()) && (startPG.getX() != endPG.getX()) && (startPG.getX() < endPG.getX())){
                            moveToEast(startPG, endPG);
                        }else{
                            if((startPG.getY() == endPG.getY()) && (startPG.getX() != endPG.getX()) && (startPG.getX() > endPG.getX())){
                                moveToWest(startPG, endPG);
                            }else{
                                if((startPG.getX() != endPG.getX()) && (startPG.getY() != endPG.getY()) && (startPG.getX() < endPG.getX()) && (startPG.getY() < endPG.getY())){
                                    moveToNorthEast(startPG, endPG);
                                }else{
                                    if((startPG.getX() != endPG.getX()) && (startPG.getY() != endPG.getY()) && (startPG.getX() < endPG.getX()) && (startPG.getY() > endPG.getY())){
                                        moveToSouthEast(startPG, endPG);
                                    }else{
                                        if((startPG.getX() != endPG.getX()) && (startPG.getY() != endPG.getY()) && (startPG.getX() > endPG.getX()) && (startPG.getY() < endPG.getY())){
                                            moveToNorthWest(startPG, endPG);
                                        }else{
                                            moveToSouthWest(startPG, endPG);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if(!listEvt.isEmpty()){
                for(int i=0;i<listEvt.size();i++){
                    listEvt.get(i).evtFinishMove(Movement.this);
                }
            }
        }
        
        private void moveToCenter(Point startPG, Point endPG){
            Point p = startPG.translatePointGraphToPoint(componentParent);
            if(!listEvt.isEmpty()){
                for(int i=0;i<listEvt.size();i++){
                    listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                }
            }
        }
        
        private void moveToNorth(Point startPG, Point endPG){
            int cptY = startPG.getY();
            while(run && cptY <= endPG.getY()){
                move = true;
                sleep();
                verifyPause();
                Point p = new Point(startPG.getX(), cptY);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptY++;
            }
            move = false;
        }
        
        private void moveToSouth(Point startPG, Point endPG){
            int cptY = startPG.getY();
            while(run && cptY >= endPG.getY()){
                move = true;
                sleep();
                verifyPause();
                Point p = new Point(startPG.getX(), cptY);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptY--;
            }
        }
        
        private void moveToWest(Point startPG, Point endPG){
            int cptX = startPG.getX();
            while(run && cptX >= endPG.getX()){
                move = true;
                sleep();
                verifyPause();
                Point p = new Point(cptX, start.getY());
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX--;
            }
        }
        
        private void moveToEast(Point startPG, Point endPG){
            int cptX = startPG.getX();
            while(run && cptX <= endPG.getX()){
                move = true;
                sleep();
                verifyPause();
                Point p = new Point(cptX, start.getY());
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX++;
            }
        }
        
        private void moveToNorthWest(Point startPG, Point endPG){
            float coef = (float)(endPG.getY()-startPG.getY())/(float)(endPG.getX()-startPG.getX());
            float orig = startPG.getY()-(float)(coef*startPG.getX());
            
            int cptX = startPG.getX();
            int oldY = startPG.getY();
            while (run && cptX >= endPG.getX()) {
                move = true;
                sleep();
                verifyPause();
                int y = (int) ((coef * cptX) + orig);
                
                int diff = y-oldY;
                if(diff>1){
                    for(int j=oldY+1;j<(oldY+diff);j++){
                        Point p = new Point(cptX, j);
                        p = p.translatePointGraphToPoint(componentParent);
                        component.setLocation(p.getX(), p.getY());
                        if(!listEvt.isEmpty()){
                            for(int i=0;i<listEvt.size();i++){
                                listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                            }
                        }
                        sleep();
                    }
                }
                
                
                
                Point p = new Point(cptX, y);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX--;
                oldY = y;
            }
        }
        
        private void moveToSouthWest(Point startPG, Point endPG){
            float coef = (float)(endPG.getY()-startPG.getY())/(float)(endPG.getX()-startPG.getX());
            float orig = startPG.getY()-(float)(coef*startPG.getX());
            
            int cptX = startPG.getX();
            int oldY = startPG.getY();
            while (run && cptX >= endPG.getX()) {
                move = true;
                sleep();
                verifyPause();
                int y = (int) ((coef * cptX) + orig);
                
                
                int diff = oldY-y;
                if(diff>1){
                    for(int j=oldY-1;j>(oldY-diff);j--){
                        Point p = new Point(cptX, j);
                        p = p.translatePointGraphToPoint(componentParent);
                        component.setLocation(p.getX(), p.getY());
                        if(!listEvt.isEmpty()){
                            for(int i=0;i<listEvt.size();i++){
                                listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                            }
                        }
                        sleep();
                    }
                }
                
                
                Point p = new Point(cptX, y);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX--;
                oldY = y;
            }
        }
        
        private void moveToNorthEast(Point startPG, Point endPG){
            float coef = (float)(endPG.getY()-startPG.getY())/(float)(endPG.getX()-startPG.getX());
            float orig = startPG.getY()-(float)(coef*startPG.getX());
            
            int cptX = startPG.getX();
            int oldY = startPG.getY();
            while (run && cptX <= endPG.getX()) {
                move = true;
                sleep();
                verifyPause();
                int y = (int) ((coef * cptX) + orig);
                
                
                int diff = y-oldY;
                if(diff>1){
                    for(int j=oldY+1;j<(oldY+diff);j++){
                        Point p = new Point(cptX, j);
                        p = p.translatePointGraphToPoint(componentParent);
                        component.setLocation(p.getX(), p.getY());
                        if(!listEvt.isEmpty()){
                            for(int i=0;i<listEvt.size();i++){
                                listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                            }
                        }
                        sleep();
                    }
                }
                
                
                Point p = new Point(cptX, y);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX++;
                oldY = y;
            }
        }
        
        private void moveToSouthEast(Point startPG, Point endPG){
            float coef = (float)(endPG.getY()-startPG.getY())/(float)(endPG.getX()-startPG.getX());
            float orig = startPG.getY()-(float)(coef*startPG.getX());
            
            int cptX = startPG.getX();
            int oldY = startPG.getY();
            while (run && cptX <= endPG.getX()) {
                move = true;
                sleep();
                verifyPause();
                
                int y = (int) ((coef * cptX) + orig);
                
                int diff = oldY-y;
                if(diff>1){
                    for(int j=oldY-1;j>(oldY-diff);j--){
                        Point p = new Point(cptX, j);
                        p = p.translatePointGraphToPoint(componentParent);
                        component.setLocation(p.getX(), p.getY());
                        if(!listEvt.isEmpty()){
                            for(int i=0;i<listEvt.size();i++){
                                listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                            }
                        }
                        sleep();
                    }
                }
                
                Point p = new Point(cptX, y);
                p = p.translatePointGraphToPoint(componentParent);
                component.setLocation(p.getX(), p.getY());
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPositionMove(Movement.this, p.getX(), p.getY());
                    }
                }
                cptX++;
                oldY = y;
            }
        }
        
        private void sleep(){
            try {
                Thread.sleep(speed);
            } catch (InterruptedException ex) {
                Logger.getLogger(Movement.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        @SuppressWarnings("SleepWhileInLoop")
        private void verifyPause(){
            if(pause){
                move = false;
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtPauseMove(Movement.this);
                    }
                }
                while (pause) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Movement.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(!listEvt.isEmpty()){
                    for(int i=0;i<listEvt.size();i++){
                        listEvt.get(i).evtStartMove(Movement.this);
                    }
                }
            }
        }

        @Override
        public void evtStartMove(Movement m) {
            started = true;
            paused = false;
        }

        @Override
        public void evtPauseMove(Movement m) {
            paused = true;
        }

        @Override
        public void evtFinishMove(Movement m) {
            started = false;
        }

        @Override
        public void evtPositionMove(Movement m, int x, int y) {
            
        }
    }
    
    /**
     * Correspond à la classe qui va faire la traduction des positions réelle aux positions graphiques mathématiques dans un repère orthonormé
     */
    private class Point {
    
        private int x;
        private int y;

        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

        public Point translatePointToPointGraph(Component c){
            return translatePointToPointGraph(c.getWidth(), c.getHeight());
        }

        public Point translatePointToPointGraph(int width, int height){
            return new Point(this.x, height-this.y);
        }

        public Point translatePointGraphToPoint(Component c){
            return translatePointGraphToPoint(c.getWidth(), c.getHeight());
        }

        public Point translatePointGraphToPoint(int width, int height){
            return new Point(this.x, height-this.y);
        }

        @Override
        public String toString() {
            return "Point{" + "x=" + x + ", y=" + y + '}';
        }

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 79 * hash + this.x;
            hash = 79 * hash + this.y;
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Point other = (Point) obj;
            if (this.x != other.x) {
                return false;
            }
            return this.y == other.y;
        }
    }
}