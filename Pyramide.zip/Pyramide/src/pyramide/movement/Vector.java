/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pyramide.movement;



/**
 * Cette classe permet de créer des vecteurs de déplacement
 * @author Léa
 */
public class Vector {

    
    
    private java.awt.Point start;
    private java.awt.Point end;

    
    
//CONSTRUCTORS
    /**
     * Crée un vecteur
     * @param start Correspond à la position de départ
     * @param end Correspond à la position d'arrivée
     */
    public Vector(java.awt.Point start, java.awt.Point end) {
        this.start  = start;
        this.end    = end;
    }
    
    /**
     * Crée un vecteur
     * @param xStart Correspond à la coordonnée x de la position de départ
     * @param yStart Correspond à la coordonnée y de la position de départ
     * @param xEnd Correspond à la coordonnée x de la position d'arrivée
     * @param yEnd Correspond à la coordonnée y de la position d'arrivée
     */
    public Vector(int xStart, int yStart, int xEnd, int yEnd){
        this.start  = new java.awt.Point(xStart, yStart);
        this.end    = new java.awt.Point(xEnd, yEnd);
    }

    
    
//METHODES PUBLICS
    /**
     * Renvoie la position de départ
     * @return Retourne la position de départ
     */
    public java.awt.Point getStart() {
        return start;
    }

    /**
     * Modifie la position de départ
     * @param start Correspond à la position de départ
     */
    public void setStart(java.awt.Point start) {
        this.start = start;
    }

    /**
     * Renvoie la position de d'arrivée
     * @return Retourne la position de d'arrivée
     */
    public java.awt.Point getEnd() {
        return end;
    }

    /**
     * Modifie la position d'arrivée
     * @param end Correspond à la position d'arrivée
     */
    public void setEnd(java.awt.Point end) {
        this.end = end;
    }
    
}
